title: CDH学习笔记
date: '2019-08-23 15:05:16'
updated: '2019-08-28 11:08:49'
tags: [hadoop, CDH]
permalink: /articles/2019/08/23/1566543916515.html
---
# 参考文档
官方文档：[https://www.cloudera.com/documentation.html](https://www.cloudera.com/documentation.html)
汉化资源百度云盘
链接：[https://pan.baidu.com/s/1tTH-fDvRKlpUhOExcrs1yg](https://pan.baidu.com/s/1tTH-fDvRKlpUhOExcrs1yg) 
提取码: 169s 

# 操作前准备

修改 C:\Windows\System32\drivers\etc\hosts 文件，根据别名映射ip，修改前注意备份
![image.png](https://img.hacpai.com/file/2019/08/image-16dc3be9.png)
![image.png](https://img.hacpai.com/file/2019/08/image-85f25c58.png)

# CDH 概述
CDH是Apache Hadoop和相关项目中最完整、经过测试和流行的发行版。CDH提供Hadoop的核心元素——可伸缩存储和分布式计算——以及基于web的用户界面和重要的企业功能。CDH是apache授权的开放源码，是惟一提供统一批处理、交互式SQL和交互式搜索以及基于角色的Hadoop解决方案

CDH特性及支持：
* 灵活性——存储任何类型的数据，并使用各种不同的计算框架进行操作，包括批处理、交互式SQL、免费文本搜索、机器学习和统计计算。  
* 集成—在一个完整的Hadoop平台上快速启动和运行，该平台可以使用多种硬件和软件解决方案。  
* 安全-处理和控制敏感数据。  
* 可伸缩性——支持广泛的应用程序和可伸缩性，并扩展它们以满足需求。  
* 高可用性——稳定执行关键业务任务。  
![image.png](https://www.cloudera.com/documentation/enterprise/6/6.3/images/cdh.png)

# 总结
CDH可以大大简化运维人员搭建和维护hadoop集群的工作量，方便开发人员实时监测任务执行情况。快速搭建大数据服务，降低使用门槛







