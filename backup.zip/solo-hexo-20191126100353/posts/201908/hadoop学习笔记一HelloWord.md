title: hadoop学习笔记<一>—Hello Word
date: '2019-08-27 15:40:23'
updated: '2019-08-28 11:12:13'
tags: [hadoop, HDFS]
permalink: /articles/2019/08/27/1566891623506.html
---
# 项目搭建
1. 构建maven 项目 big_data_hadoop，配置pom.xml 添加必要依赖
``` xml
  <dependencies>
        <dependency>
            <groupId>org.apache.hadoop</groupId>
            <artifactId>hadoop-common</artifactId>
            <version>2.6.0</version>
        </dependency>
        <dependency>
            <groupId>org.apache.hadoop</groupId>
            <artifactId>hadoop-hdfs</artifactId>
            <version>2.6.0</version>
        </dependency>
        <dependency>
            <groupId>org.apache.hadoop</groupId>
            <artifactId>hadoop-client</artifactId>
            <version>2.6.0</version>
        </dependency>
    </dependencies>

```

2. 创建测试 ShowFile.java
```
package com.jiuqi.example;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IOUtils;

import java.io.InputStream;
import java.net.URI;

/**
 * @description:
 * @author: zfei
 * @create: 2019-08-28
 * @version: 1.0
 **/
public class ShowFile {

	public static void main(String[] args) throws Exception {
		//hdfs的地址 已经配置host 解析
		String uri = "hdfs://bigdb01:8020/";
		Configuration config = new Configuration();
		FileSystem fs = FileSystem.get(URI.create(uri), config);

		// 列出hdfs上/tmp/logs/目录下的所有文件和目录
		FileStatus[] statuses = fs.listStatus(new Path("/tmp/logs"));
		for (FileStatus status : statuses) {
			System.out.println(status);
		}

		// 在hdfs的/tmp/logs目录下创建一个文件，并写入一行文本
		FSDataOutputStream os = fs.create(new Path("/tmp/logs/test.log"));
		os.write("Hello World!".getBytes());
		os.flush();
		os.close();

		// 显示在hdfs的/tmp/logs下指定文件的内容
		InputStream is = fs.open(new Path("/tmp/logs/test.log"));
		IOUtils.copyBytes(is, System.out, 1024, true);
	}
}

```

3. 执行后进入CDH后台查看执行结果
![image.png](https://img.hacpai.com/file/2019/08/image-7c6004ba.png)
![image.png](https://img.hacpai.com/file/2019/08/image-dcd70b75.png)
![image.png](https://img.hacpai.com/file/2019/08/image-02ce7447.png)
![image.png](https://img.hacpai.com/file/2019/08/image-26a1f231.png)
![image.png](https://img.hacpai.com/file/2019/08/image-39fa5cf4.png)

4. 执行成功，HDFS已存在文件，下载后验证数据正常







