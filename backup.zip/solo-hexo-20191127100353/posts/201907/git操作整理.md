title: git操作整理
date: '2019-07-12 17:29:18'
updated: '2019-07-30 17:59:25'
tags: [git]
permalink: /articles/2019/07/12/1562923758794.html
---
### 在 Linux 上安装
如果要在 Linux 上安装预编译好的 Git 二进制安装包，可以直接用系统提供的包管理工具。在 CentOS 上用 yum 安装：

``` shell
yum install curl-devel expat-devel gettext-devel openssl-devel zlib-devel
yum -y install git-core
git --version
```
常用命令
```
#拉取仓库
git clone [repository]
#同步远端
git pull [repository]

```
