title: mongodb实战
date: '2019-07-23 16:39:09'
updated: '2019-07-31 14:34:23'
tags: [db, mongo]
permalink: /articles/2019/07/23/1563871149149.html
---
![](https://img.hacpai.com/bing/20190629.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

公司记录分析客户行为的功能打算从现有产品模块的关系型数据存储系统中进行分离，故基于非关系型数据mongodb进行技术解决方案的设计。
# 安装mongodb服务
[使用docker进行部署服务](https://www.runoob.com/docker/docker-install-mongodb.html)

``` shell
#搜索镜像
docker search mongo
#下载镜像
docker pull mongo
#于当前目录生成映射数据库文件   最好映射在存量较大的磁盘中 启动
docker run -p 27017:27017 -v $PWD/mongo/db:/data/db -d mongo
#本地连接 数据库 host 为出网ip   这里会开启一个新的容器所以即用即删
docker run -it --rm mongo mongo --host [host]
```
进入操作命令行
![image.png](https://img.hacpai.com/file/2019/07/image-a6e26d6a.png)

``` shell
#用[]的代码为变量
#显示当前存在的数据库
show dbs;
#创建数据库
use [database_name];
#插入数据 （只有插入数据后的新建数据库才会显示在数据库列表中）
db.[database_name].insert({"name":"测试数据"});
#删除数据库
use [database_name];
db.dorpDatabase();
#显示当前存在的集合
show tables;
show collections;
#创建集合
db.createCollection("[collection_name]");
#删除集合
db.[collection_name].drop();
#查看集合中存在的数据
db.[collection_name].find();
#集合中插入数据
db.[collection_name].insert([json])
#批量插入多条数据
  var arr =  [];
  for(var i=1;i<=20000;i++){
    arr.push({num:i});  
  } 
  db.numbers.insert(arr);
```

# 安装mongodb可视化客户端
作者本人使用的是 Navicat for MongoDB 客户端

# 数据源数据模型设计
数据库： scrm
数据集合：t_customer_behavior
数据文档样例：
``` json
{
	"customerId": 12,
	"sourceType": 1,
	"sourceId": 23,
	"actionType": 2,
	"actionId": 14,
	"money": 7.6,
	"integral": 8,
	"behaviorTime": "2019-07-31 12:33:12",
	"behaviorDescribe": "SCRM|商城|数据。。。。"
}
```
传输文档数据描述：

| 字段 | 字段名 | 字段描述 | 必填 |索引 |
| --- | --- | --- | --- | --- |
| 客户id | customer_id | scrm customer表主键 | 是 | 有 |
| 来源类型 | source_type | 来源关系参考[数据字典](http://scrmapidoc.evermotion.cn/web/#/page/235) | 是 | 有 |
| 矩阵Id | source_id | 如微信来源 微信公众号 | 否 | 有 |
| 动作类型 | action_type| 来源关系参考[数据字典](http://scrmapidoc.evermotion.cn/web/#/page/235)| 是 | 有 |
| 动作对象 | action_id | 如抽奖页面按钮id，表单页面id 可能是微信消息类型（如文本）| 否 | 有|
| 金额 | money |  | 否 | 有 |
| 积分 | integral |  | 否 | 有 |
| 行为发生时间 | behavior_time | | 是 | 有 |
| 行为发生描述 | behavior_describe| | 否 | 无 |