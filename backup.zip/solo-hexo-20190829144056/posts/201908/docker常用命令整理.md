title: docker常用命令整理
date: '2019-08-01 10:47:20'
updated: '2019-08-01 10:47:20'
tags: [docker, command]
permalink: /articles/2019/08/01/1564627639954.html
---
```shell
#查看当前执行中的容器
docker ps
#查看web服务日志
docker logs -f [name]
```