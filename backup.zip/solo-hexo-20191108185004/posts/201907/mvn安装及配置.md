title: mvn安装及配置
date: '2019-07-30 18:17:15'
updated: '2019-08-01 10:50:12'
tags: [maven, environment]
permalink: /articles/2019/07/30/1564481835296.html
---
下载及解压
``` shell
wget http://mirrors.hust.edu.cn/apache/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz
tar -xvf  apache-maven-3.3.9-bin.tar.gz 
mv -f apache-maven-3.3.9 /usr/local/
```
编辑 **/etc/profile** 文件 sudo vim /etc/profile，在文件末尾添加如下代码：
``` shell
export MAVEN_HOME=/usr/local/apache-maven-3.3.9
export PATH=${PATH}:${MAVEN_HOME}/bin
```
保存文件，并运行如下命令使环境变量生效：

``` shell
source /etc/profile
```

在控制台输入如下命令，如果能看到 Maven 相关版本信息，则说明 Maven 已经安装成功：

``` shell
mvn -v
```
