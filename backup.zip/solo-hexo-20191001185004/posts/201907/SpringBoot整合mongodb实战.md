title: SpringBoot整合mongodb实战
date: '2019-07-24 14:33:20'
updated: '2019-08-01 11:29:47'
tags: [Spring, SpringBoot, mongo]
permalink: /articles/2019/07/24/1563950000373.html
---
![](https://img.hacpai.com/bing/20190108.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

客户行为日志存储需要用到mongodb，故专门整如何在SpringBoot中整合mongodb的实现
# 引用maven依赖
``` xml
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-data-mongodb</artifactId>
</dependency>
```
# 配置数据源
``` properties
#默认 port 27017 无密码
spring.data.mongodb.uri=mongodb://[host]:[port]/[db_name]
#存在密码
spring.data.mongodb.uri=mongodb://[user]:[pwd]@[host]:[port]/[database]
#如果多个节点集群配置
spring.data.mongodb.uri=mongodb://[user]:[pwd]@[host1]:[port1],[host2]:[port2]/[database]
```
# 数据持久层
客户行为实体类
``` java
package com.jiuqi.worm.web.entity;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @description: 用于接收及存储用户行为
 * @author: zfei
 * @create: 2019-07-24
 * @version: 1.0
 **/
@Data
@Document(collection = "t_customer_behavior")
public class CustomerBehavior {

	private String id;
	@Field("customer_id")
	private Integer customerId;
	@Field("source_type")
	private Integer sourceType;
	@Field("source_id")
	private Integer sourceId;
	@Field("action_type")
	private Integer actionType;
	@Field("action_id")
	private Integer actionId;
	private BigDecimal money;
	private Integer integral;
	@Field("behavior_time")
	private Date behaviorTime;
	@Field("behavior_describe")
	private String behaviorDescribe;

	public CustomerBehavior(){}

	public CustomerBehavior(Integer customerId,Integer sourceType,Integer actionType,DatebehaviorTime){
		this.customerId = customerId;
		this.sourceType = sourceType;
		this.actionType = actionType;
		this.behaviorTime = behaviorTime;
	}
}

```

数据持久化及查询的实现方式有两种

## 方式一  MongoTemplate
springboot会自动注入mongotemplate,使用引用
``` java

```

## 方式二 MongoRepository
数据持久层代码
``` java
package com.jiuqi.worm.web.repository;

import com.jiuqi.worm.web.entity.CustomerBehavior;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerBehaviorRepository extends MongoRepository<CustomerBehavior,String>{

}
```

# 业务逻辑编写

``` java
package com.jiuqi.worm.web.behavior.service.impl;

import com.jiuqi.worm.util.GsonUtil;
import com.jiuqi.worm.web.behavior.dto.CustomerAnalysisDto;
import com.jiuqi.worm.web.behavior.service.CustomerBehaviorService;
import com.jiuqi.worm.web.behavior.vo.CustomerAnalysisVo;
import com.jiuqi.worm.web.behavior.vo.CustomerBehaviorVo;
import com.jiuqi.worm.web.entity.CustomerBehavior;
import com.jiuqi.worm.web.repository.CustomerBehaviorRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * @description: 业务层
 * @author: zfei
 * @create: 2019-07-24
 * @version: 1.0
 **/
@Service
@Slf4j
public class CustomerBehaviorServiceImpl implements CustomerBehaviorService {

	@Autowired
	private CustomerBehaviorRepository repository;
	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public boolean insert(CustomerBehavior record) {
		CustomerBehavior customerBehavior = repository.insert(record);
		log.info("数据持久化后的对象：[{}]", GsonUtil.objToString(customerBehavior));
		return StringUtils.isNotEmpty(customerBehavior.getId());
	}

	@Override
	public List<CustomerAnalysisVo> getCustomerAnalysis(CustomerAnalysisDto dto) {
		return null;
	}

	@Override
	public List<CustomerBehaviorVo> getCustomerCustomerBehaviorList(CustomerAnalysisDto dto) {
		return null;
	}
}

```
# mongodb日志打印
使用logback配置日志，添加 logback-spring.xml 配置
``` xml
    <!-- mongodb语句输出 -->
    <logger name="org.springframework.data.mongodb.core" level="DEBUG"/>
```
# 测试代码
```
package com.jiuqi.worm.web.behavior;

import com.jiuqi.worm.web.behavior.service.CustomerBehaviorService;
import com.jiuqi.worm.web.entity.CustomerBehavior;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @description:
 * @author: zfei
 * @create: 2019-07-24
 * @version: 1.0
 **/
@RunWith(SpringRunner.class)
@SpringBootTest
@Slf4j
public class CustomerBehaviorTest {

	@Autowired
	private CustomerBehaviorService customerBehaviorService;

	@Test
	public void insert(){
		CustomerBehavior customerBehavior = new CustomerBehavior("122131","1","5","2019-11-13 11:43:21");
		boolean b = customerBehaviorService.insert(customerBehavior);
		log.info("插入操作结果[{}]",b);
	}
}

```
执行结果：
![image.png](https://img.hacpai.com/file/2019/07/image-a0fd3234.png)
![image.png](https://img.hacpai.com/file/2019/07/image-fd5a2ec0.png)


